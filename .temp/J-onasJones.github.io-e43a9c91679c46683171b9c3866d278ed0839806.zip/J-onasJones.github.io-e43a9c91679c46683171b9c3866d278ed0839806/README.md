# J-onasJones.github.io

You just found the repo for my Homepage (http://jonasjones.me/) I guess. It's still a wip (work in progress) but some of it is already done although it is definetly not final

# License

This project is currently under the DWTFYW License which is subject to change.
